class AppConfig {
  static const String backendUrl = 'https://backend-nextchat.up.railway.app';
  static const String wsUrl      = 'wss://backend-nextchat.up.railway.app';
  static const int maxUpload = 200 * 1024 * 1024;
  static const String kSession    = 'nexchat_session';
  static const String kTheme      = 'nexchat_theme';
  static const String kPermsAsked = 'nexchat_perms';
  static const Duration statusTtl = Duration(hours: 24);
}
