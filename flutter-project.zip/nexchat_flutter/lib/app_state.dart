import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'config.dart';

class AppState {
  AppState._();
  static final AppState instance = AppState._();
  final ValueNotifier<String> loggedUser  = ValueNotifier('');
  final ValueNotifier<String> sessionId   = ValueNotifier('');
  final ValueNotifier<String> displayName = ValueNotifier('');
  final ValueNotifier<String?> avatar     = ValueNotifier(null);
  final ValueNotifier<String> bio         = ValueNotifier('');
  final ValueNotifier<bool>   isDev       = ValueNotifier(false);
  final ValueNotifier<String> theme       = ValueNotifier('dark');
  final ValueNotifier<List<Map<String, dynamic>>> chatList = ValueNotifier([]);
  final ValueNotifier<Map<String, Map<String, dynamic>>> peers = ValueNotifier({});
  final ValueNotifier<String> openChatId = ValueNotifier('');

  Future<void> loadSession() async {
    final sp = await SharedPreferences.getInstance();
    theme.value = sp.getString(AppConfig.kTheme) ?? 'dark';
    final raw = sp.getString(AppConfig.kSession);
    if (raw == null) return;
    try {
      final m = jsonDecode(raw) as Map<String, dynamic>;
      loggedUser.value  = (m['username']  ?? '').toString();
      sessionId.value   = (m['sessionId'] ?? '').toString();
      displayName.value = (m['displayName'] ?? '').toString();
      avatar.value      = m['avatar'] as String?;
      bio.value         = (m['bio'] ?? '').toString();
      isDev.value       = m['isDev'] == true;
      if (m['theme'] != null && (m['theme'] as String).isNotEmpty) {
        theme.value = m['theme'].toString();
      }
    } catch (_) {}
  }

  Future<void> saveSession({
    required String username, required String sessionIdStr,
    String? display, String? avatarUrl, String? bioText,
    bool? dev, String? themeId,
  }) async {
    loggedUser.value = username;
    sessionId.value  = sessionIdStr;
    if (display != null) displayName.value = display;
    if (avatarUrl != null) avatar.value = avatarUrl;
    if (bioText != null) bio.value = bioText;
    if (dev != null) isDev.value = dev;
    if (themeId != null) theme.value = themeId;
    final sp = await SharedPreferences.getInstance();
    await sp.setString(AppConfig.kSession, jsonEncode({
      'username': username, 'sessionId': sessionIdStr,
      'displayName': displayName.value, 'avatar': avatar.value,
      'bio': bio.value, 'isDev': isDev.value, 'theme': theme.value,
      'ts': DateTime.now().millisecondsSinceEpoch,
    }));
  }

  Future<void> updateProfile({
    String? display, String? avatarUrl, String? bioText, bool clearAvatar = false,
  }) async {
    if (display != null) displayName.value = display;
    if (clearAvatar) avatar.value = null;
    if (avatarUrl != null) avatar.value = avatarUrl;
    if (bioText != null) bio.value = bioText;
    await saveSession(username: loggedUser.value, sessionIdStr: sessionId.value,
      display: displayName.value, avatarUrl: avatar.value, bioText: bio.value,
      dev: isDev.value, themeId: theme.value);
  }

  Future<void> setTheme(String themeId) async {
    theme.value = themeId;
    final sp = await SharedPreferences.getInstance();
    await sp.setString(AppConfig.kTheme, themeId);
  }

  Future<void> clear() async {
    final sp = await SharedPreferences.getInstance();
    await sp.remove(AppConfig.kSession);
    loggedUser.value = ''; sessionId.value = ''; displayName.value = '';
    avatar.value = null; bio.value = ''; isDev.value = false;
    chatList.value = []; peers.value = {};
  }
}
