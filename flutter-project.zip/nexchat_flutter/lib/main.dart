import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_state.dart';
import 'services/notification_service.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'widgets/incoming_call_overlay.dart';

final GlobalKey<NavigatorState> mainNavKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await NotificationService.instance.init();
  await AppState.instance.loadSession();
  runApp(const NexChatApp());
}

class NexChatApp extends StatelessWidget {
  const NexChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: AppState.instance.loggedUser,
      builder: (_, user, __) {
        if (user.isEmpty) {
          return const _LoginRoot();
        }
        return const _MainRoot();
      },
    );
  }
}

class _LoginRoot extends StatelessWidget {
  const _LoginRoot();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NexChat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00A884),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF0F2F5),
      ),
      themeMode: ThemeMode.light,
      home: const LoginScreen(),
    );
  }
}

class _MainRoot extends StatelessWidget {
  const _MainRoot();
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: AppState.instance.theme,
      builder: (_, themeId, __) {
        return MaterialApp(
          title: 'NexChat',
          navigatorKey: mainNavKey,
          debugShowCheckedModeBanner: false,
          theme: _buildTheme(themeId),
          home: const HomeScreen(),
          builder: (context, child) {
            return Stack(
              children: [
                Positioned.fill(
                  child: child ?? const SizedBox.shrink(),
                ),
                const Positioned.fill(
                  child: IncomingCallOverlay(),
                ),
              ],
            );
          },
        );
      },
    );
  }

  ThemeData _buildTheme(String id) {
    Color accent;
    Color bg;
    Brightness brightness;
    switch (id) {
      case 'light':
        accent = const Color(0xFF00A884); bg = const Color(0xFFF0F2F5); brightness = Brightness.light; break;
      case 'blue':
        accent = const Color(0xFF1976D2); bg = const Color(0xFFE3F2FD); brightness = Brightness.light; break;
      case 'green':
        accent = const Color(0xFF2E7D32); bg = const Color(0xFFE8F5E9); brightness = Brightness.light; break;
      case 'purple':
        accent = const Color(0xFF8E24AA); bg = const Color(0xFFF3E5F5); brightness = Brightness.light; break;
      case 'orange':
        accent = const Color(0xFFEF6C00); bg = const Color(0xFFFFF3E0); brightness = Brightness.light; break;
      default:
        accent = const Color(0xFF00A884); bg = const Color(0xFF0B141A); brightness = Brightness.dark;
    }
    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: brightness),
      scaffoldBackgroundColor: bg,
      appBarTheme: AppBarTheme(
        backgroundColor: brightness == Brightness.light ? Colors.white : const Color(0xFF202C33),
        foregroundColor: brightness == Brightness.light ? Colors.black : Colors.white,
        elevation: 0,
      ),
    );
  }
}
